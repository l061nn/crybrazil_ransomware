﻿/*
 
 * ce programme decryptes les fichiers ,utliser une machine virtuele pour tester.
 * je ne suis pas responsable de vos actes.
 * faite attention .
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security;
using System.Security.Cryptography;
using System.IO;
using System.Net;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;


namespace Gendarmerie_decrypter
{
    public partial class Form1 : Form
    {
        string userName = Environment.UserName;
        string userDir = "C:\\Users\\";

        public Form1()
        {
            InitializeComponent();
        }

        public byte[] AES_Decrypt(byte[] bytesToBeDecrypted, byte[] passwordBytes)
        {
            byte[] decryptedBytes = null;

            // Set your salt here, change it to meet your flavor:
            // The salt bytes must be at least 8 bytes.
            byte[] saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

            using (MemoryStream ms = new MemoryStream())
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {

                    AES.KeySize = 256;
                    AES.BlockSize = 128;

                    var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
                    AES.Key = key.GetBytes(AES.KeySize / 8);
                    AES.IV = key.GetBytes(AES.BlockSize / 8);

                    AES.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(ms, AES.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
                        cs.Close();
                    }
                    decryptedBytes = ms.ToArray();


                }
            }

            return decryptedBytes;
        }

        public void DecryptFile(string file, string password)
        {

            byte[] bytesToBeDecrypted = File.ReadAllBytes(file);
            byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
            passwordBytes = SHA256.Create().ComputeHash(passwordBytes);

            byte[] bytesDecrypted = AES_Decrypt(bytesToBeDecrypted, passwordBytes);

            File.WriteAllBytes(file, bytesDecrypted);
            string extension = System.IO.Path.GetExtension(file);
            string result = file.Substring(0, file.Length - extension.Length);
            System.IO.File.Move(file, result);

        }

        public void DecryptDirectory(string location)
        {
            string password = textBox1.Text;

            string[] files = Directory.GetFiles(location);
            string[] childDirectories = Directory.GetDirectories(location);
            for (int i = 0; i < files.Length; i++)
            {
                try
                {
                    string extension = Path.GetExtension(files[i]);
                    if (extension == ".crybrazil") //extension utilisé dans le programme precedent
                    {
                        DecryptFile(files[i], password);
                    }
                }
                catch (SystemException)
                {
                    continue;
                }

            }
            for (int i = 0; i < childDirectories.Length; i++)
            {
                try
                {
                    DecryptDirectory(childDirectories[i]);
                }
                catch (SystemException)
                {
                    continue;
                }
            }
            label3.Visible = true;

        }


        private void button1_Click(object sender, EventArgs e)
        {
            string path = "\\Desktop";
            string pathdow2 = "\\Downloads";
            string pathdoc = "\\Documents";
            string pathim = "\\Pictures";
            string pathmu = "\\Music";
            string pathvi = "\\Videos";
            string fullpath = userDir + userName + path;
            string fullpathdow = userDir + userName + pathdow2;
            string fullpathdoc = userDir + userName + pathdoc;
            string fullpathim = userDir + userName + pathim;
            string fullpathmu = userDir + userName + pathmu;
            string fullpathvi = userDir + userName + pathvi;
            DecryptDirectory(fullpath);
            DecryptDirectory(fullpathdow);
            DecryptDirectory(fullpathdoc);
            DecryptDirectory(fullpathim);
            DecryptDirectory(fullpathmu);
            DecryptDirectory(fullpathvi);

        }

      
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
